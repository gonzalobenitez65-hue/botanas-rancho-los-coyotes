package com.rancholoscoyotes.app

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val unitPrice: Double,
    val stock: Int = 0
)

@Entity(tableName = "sales")
data class Sale(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val customerName: String,
    val total: Double,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "sale_lines")
data class SaleLine(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val saleId: Long,
    val productName: String,
    val quantity: Int,
    val unitPrice: Double
)

@Dao
interface StoreDao {
    @Query("SELECT * FROM products ORDER BY name") fun products(): Flow<List<Product>>
    @Insert suspend fun addProduct(product: Product)
    @Update suspend fun updateProduct(product: Product)
    @Query("SELECT * FROM products WHERE id = :id") suspend fun product(id: Long): Product?
    @Insert suspend fun addSale(sale: Sale): Long
    @Insert suspend fun addLines(lines: List<SaleLine>)
    @Query("SELECT * FROM sales ORDER BY createdAt DESC") fun sales(): Flow<List<Sale>>
    @Query("SELECT * FROM sale_lines WHERE saleId = :saleId") suspend fun lines(saleId: Long): List<SaleLine>
    @Query("UPDATE products SET stock = MAX(0, stock - :qty) WHERE id = :productId")
    suspend fun decreaseStock(productId: Long, qty: Int)
}

@Database(entities = [Product::class, Sale::class, SaleLine::class], version = 1, exportSchema = false)
abstract class StoreDatabase : RoomDatabase() {
    abstract fun dao(): StoreDao
    companion object {
        @Volatile private var INSTANCE: StoreDatabase? = null
        fun get(context: Context): StoreDatabase = INSTANCE ?: synchronized(this) {
            INSTANCE ?: Room.databaseBuilder(context.applicationContext, StoreDatabase::class.java, "rancho_coyotes.db")
                .build().also { INSTANCE = it }
        }
    }
}

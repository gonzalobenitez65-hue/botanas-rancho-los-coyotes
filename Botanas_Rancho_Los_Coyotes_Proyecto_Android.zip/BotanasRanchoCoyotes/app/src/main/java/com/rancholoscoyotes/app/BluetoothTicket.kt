package com.rancholoscoyotes.app

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import java.util.UUID

/**
 * ESC/POS helper for paired 58 mm Bluetooth thermal printers.
 * Pair the printer in Android Settings first, then select its MAC address here.
 */
object BluetoothTicket {
    private val spp = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    fun pairedPrinters(adapter: BluetoothAdapter): List<BluetoothDevice> =
        adapter.bondedDevices?.toList().orEmpty()

    fun print(adapter: BluetoothAdapter, mac: String, text: String) {
        val device = adapter.getRemoteDevice(mac)
        val socket = device.createRfcommSocketToServiceRecord(spp)
        socket.connect()
        socket.outputStream.use { out ->
            out.write(byteArrayOf(0x1B, 0x40)) // initialize
            out.write(text.toByteArray(Charsets.US_ASCII))
            out.write(byteArrayOf(0x0A, 0x0A, 0x0A))
            out.write(byteArrayOf(0x1D, 0x56, 0x00)) // full cut (if supported)
            out.flush()
        }
        socket.close()
    }
}

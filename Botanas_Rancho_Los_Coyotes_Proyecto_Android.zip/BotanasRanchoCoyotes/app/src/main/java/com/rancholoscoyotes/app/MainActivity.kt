package com.rancholoscoyotes.app

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val RanchRed = Color(0xFF9D211B)
private val RanchYellow = Color(0xFFFFD34E)
private val Parchment = Color(0xFFFFF1CE)

class MainActivity : ComponentActivity() {
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val needed = if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN) else emptyArray()
        if (needed.any { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }) permissionLauncher.launch(needed)
        val db = StoreDatabase.get(this)
        setContent { RanchApp(db) }
    }
}

@Composable
fun RanchApp(db: StoreDatabase) {
    val dao = db.dao()
    val scope = rememberCoroutineScope()
    val products by dao.products().collectAsState(initial = emptyList())
    val sales by dao.sales().collectAsState(initial = emptyList())
    var screen by remember { mutableStateOf("Venta") }
    var customer by remember { mutableStateOf("") }
    var newName by remember { mutableStateOf("") }
    var newPrice by remember { mutableStateOf("") }
    var newStock by remember { mutableStateOf("") }
    var cart by remember { mutableStateOf(listOf<Pair<Product, Int>>()) }
    val total = cart.sumOf { it.first.unitPrice * it.second }

    MaterialTheme(colorScheme = lightColorScheme(primary = RanchRed, secondary = RanchYellow, background = Parchment)) {
        Scaffold(
            containerColor = Parchment,
            topBar = {
                Column(Modifier.fillMaxWidth().background(RanchRed).padding(16.dp)) {
                    Text("🤠 BOTANAS", color = RanchYellow, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Text("RANCHO LOS COYOTES", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black)
                    Text("VENTAS • INVENTARIO • CAJA", color = Color(0xFFFFE8B0), fontSize = 11.sp)
                }
            },
            bottomBar = {
                NavigationBar(containerColor = RanchRed) {
                    listOf("Venta", "Productos", "Caja").forEach { item ->
                        NavigationBarItem(
                            selected = screen == item, onClick = { screen = item },
                            icon = { Text(when(item) { "Venta" -> "🛒"; "Productos" -> "📦"; else -> "💰" }) },
                            label = { Text(item, color = Color.White) },
                            colors = NavigationBarItemDefaults.colors(indicatorColor = RanchYellow, selectedIconColor = RanchRed, unselectedIconColor = Color.White)
                        )
                    }
                }
            }
        ) { padding ->
            when(screen) {
                "Venta" -> LazyColumn(Modifier.padding(padding).fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item {
                        Text("Nueva venta", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = RanchRed)
                        OutlinedTextField(customer, { customer = it }, label = { Text("Nombre del cliente") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    }
                    items(products) { product ->
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White), shape = RoundedCornerShape(14.dp)) {
                            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(product.name, fontWeight = FontWeight.Bold)
                                    Text("$${"%.2f".format(product.unitPrice)} • Existencia: ${product.stock}", color = RanchRed)
                                }
                                Button(onClick = { cart = cart + (product to 1) }, colors = ButtonDefaults.buttonColors(containerColor = RanchRed)) { Text("Agregar") }
                            }
                        }
                    }
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Artículos: ${cart.sumOf { it.second }}")
                                Text("TOTAL: $${"%.2f".format(total)}", fontSize = 24.sp, color = RanchRed, fontWeight = FontWeight.Black)
                                Button(
                                    enabled = cart.isNotEmpty() && customer.isNotBlank(),
                                    modifier = Modifier.fillMaxWidth(),
                                    onClick = {
                                        scope.launch {
                                            val saleId = dao.addSale(Sale(customerName = customer.trim(), total = total))
                                            dao.addLines(cart.map { SaleLine(saleId = saleId, productName = it.first.name, quantity = it.second, unitPrice = it.first.unitPrice) })
                                            cart.forEach { dao.decreaseStock(it.first.id, it.second) }
                                            cart = emptyList()
                                            customer = ""
                                        }
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = RanchRed)
                                ) { Text("Guardar venta") }
                                Text("La venta queda guardada en este celular. La impresión Bluetooth se configura en el siguiente paso.", fontSize = 11.sp)
                            }
                        }
                    }
                }
                "Productos" -> LazyColumn(Modifier.padding(padding).fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    item {
                        Text("Inventario", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = RanchRed)
                        OutlinedTextField(newName, { newName = it }, label = { Text("Nombre de botana") }, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(newPrice, { newPrice = it }, label = { Text("Precio de venta") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(newStock, { newStock = it }, label = { Text("Existencia inicial") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
                        Button(
                            enabled = newName.isNotBlank() && (newPrice.toDoubleOrNull() ?: 0.0) > 0,
                            onClick = {
                                scope.launch {
                                    dao.addProduct(Product(name = newName.trim(), unitPrice = newPrice.toDouble(), stock = newStock.toIntOrNull() ?: 0))
                                    newName = ""; newPrice = ""; newStock = ""
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = RanchRed)
                        ) { Text("Agregar producto") }
                        Divider()
                    }
                    items(products) { p ->
                        ListItem(headlineContent = { Text(p.name) }, supportingContent = { Text("Precio $${"%.2f".format(p.unitPrice)} • Existencia ${p.stock}") })
                    }
                }
                else -> LazyColumn(Modifier.padding(padding).fillMaxSize().padding(14.dp)) {
                    item {
                        Text("Corte de caja", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = RanchRed)
                        Text("Ventas registradas: ${sales.size}")
                        Text("Total vendido: $${"%.2f".format(sales.sumOf { it.total })}", fontSize = 25.sp, fontWeight = FontWeight.Black, color = RanchRed)
                    }
                    items(sales) { sale ->
                        ListItem(
                            headlineContent = { Text(sale.customerName) },
                            supportingContent = { Text(SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("es", "MX")).format(Date(sale.createdAt))) },
                            trailingContent = { Text("$${"%.2f".format(sale.total)}", color = RanchRed, fontWeight = FontWeight.Bold) }
                        )
                    }
                }
            }
        }
    }
}

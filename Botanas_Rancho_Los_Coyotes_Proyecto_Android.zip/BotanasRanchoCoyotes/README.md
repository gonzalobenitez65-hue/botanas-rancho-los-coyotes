# Botanas Rancho los Coyotes — proyecto Android

Aplicación Android nativa inicial en Kotlin + Jetpack Compose.

## Incluye en esta primera versión
- Interfaz vaquera rojo/amarillo.
- Sin pantalla de contraseña.
- Base de datos Room local (no necesita internet para registrar datos).
- Alta de productos con precio de venta y existencia.
- Registro de ventas con nombre de cliente.
- Descuento de existencias y resumen de caja.
- Helper inicial ESC/POS para impresoras térmicas Bluetooth SPP de 58 mm.

## Para generar el APK
1. Abre este proyecto en Android Studio (versión compatible con Android Gradle Plugin 8.7.3).
2. Espera a que Gradle sincronice las dependencias.
3. Conecta un teléfono Android o usa un emulador.
4. Ejecuta la app para probarla.
5. Para crear un APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Importante
Este ZIP contiene el código fuente del proyecto, no un APK ya compilado.
La impresión Bluetooth requiere probar el modelo exacto de impresora y seleccionar una impresora emparejada.
El prototipo de impresión ESC/POS es una base técnica; hay impresoras de 58 mm que usan variantes distintas.
El precio de venta es configurable. No se calcula costo ni utilidad, de acuerdo con la configuración solicitada.
La versión inicial registra ventas por unidad; los precios diferenciados de paquete/mayoreo y el flujo de impresión deben completarse y probarse antes de uso comercial.
